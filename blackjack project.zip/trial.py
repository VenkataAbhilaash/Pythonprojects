from art import logo
import random

def deal_card():
  cards=[11,2,3,4,5,6,7,8,9,10,10,10,10]
  new_card=random.choice(cards)
  return new_card

def calculate_score(user):
  if sum(user)==21 and len(user)==2:
    return 0
  if 11 in user and sum(user)>21:
    user.remove(11)
    user.append(1)
  return sum(user)

def play_game():
  print(logo)
  user_choice=[]
  comp_choice=[]
  for _ in range(2):
    user_choice.append(deal_card())
    comp_choice.append(deal_card())

game=True
while game:
  user_score=calculate_score(user_choice)
  comp_score=calculate_score(comp_choice)

  if user_score==comp_score:
    print("Draw!")
  elif user_score==0:
    print("You won with a blackjack!")
  elif comp_score==0:
    prin("Computer won with a blackjack!")
  elif user_score>comp_score:
    print("User Won!")
play_game()